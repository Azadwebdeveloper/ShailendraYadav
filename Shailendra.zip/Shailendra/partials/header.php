<header id="header" class="wpo-header-style-1">
    <div class="wpo-site-header">
        <nav class="navigation navbar navbar-expand-lg navbar-light">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-3 col-3 d-lg-none dl-block">
                        <div class="mobail-menu">
                            <button type="button" class="navbar-toggler open-btn">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar first-angle"></span>
                                <span class="icon-bar middle-angle"></span>
                                <span class="icon-bar last-angle"></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-6">
                        <div class="navbar-header">
                            <a class="navbar-brand site-logo" href="index.php">
                             
                                Shailendra.</a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-1 col-1">
                        <div id="navbar" class="collapse navbar-collapse navigation-holder">
                            <button class="menu-close"><i class="ti-close"></i></button>
                            <ul class="nav navbar-nav mb-2 mb-lg-0">
                                <li >
                                    <a href="index.php">Home</a>
                                   
                                </li>
                                <li>
                                    <a href="#about">About</a>
                                </li>
                                <li >
                                    <a href="#portfolio">Portfolio</a>
                                   
                                </li>
                                <li>
                                    <a href="#testimonial">Testimonials</a>
                                          </li>
                                <li>
                                    <a href="#contact">Contact</a>
                                </li>
                            </ul>

                        </div><!-- end of nav-collapse -->
                    </div>
                    <div class="col-lg-2 col-md-2 col-2">
                        <div class="header-right">
                            <div class="header-btn">
                                <a class="theme-btn" download="My Cv" href="assets/images/doc/Shailendra-Yadav-CV.pdf"
                                    title="ImageName">
                                    <img class="hide-img" alt="ImageName" src="assets/images/doc/Shailendra-Yadav-CV.pdf">
                                    Resume
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- end of container -->
        </nav>
    </div>
</header>