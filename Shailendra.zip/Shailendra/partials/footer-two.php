<footer class="wpo-site-footer-s2">
    <div class="upper-footer">
        <div class="container">
            <div class="row">
                <div class="col col-lg-4 col-md-6 col-12">
                    <div class="widget about-widget">
                        <div class="logo widget-title">
                            <a class="site-logo" href="index.php"><img src="assets/images/logo.png"
                                    alt="">Elito.</a>
                        </div>
                        <p>Welcome and open yourself to your truest love this year with us! With the Release
                            Process</p>
                        <div class="social-icons">
                            <ul>
                                <li><a href="#"><i class="ti-facebook"></i></a></li>
                                <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                <li><a href="#"><i class="ti-vimeo-alt"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col col-lg-2 col-md-6 col-12">
                    <div class="widget link-widget">
                        <div class="widget-title">
                            <h3>Navigation</h3>
                        </div>
                        <ul>
                            <li><a href="about.php">About us</a></li>
                            <li><a href="contact.php">Contact us</a></li>
                            <li><a href="#video">Video Guide</a></li>
                            <li><a href="blog.php">Recent Post</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col col-lg-3 col-md-6 col-12">
                    <div class="widget link-widget service-link-widget">
                        <div class="widget-title">
                            <h3>All Services</h3>
                        </div>
                        <ul>
                            <li><a href="service-single.php">Web Design</a></li>
                            <li><a href="service-single.php">Web Development</a></li>
                            <li><a href="service-single.php">Brand Identity</a></li>
                            <li><a href="service-single.php">Digital Marketing</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col col-lg-3 col-md-6 col-12">
                    <div class="widget newsletter-widget">
                        <div class="widget-title">
                            <h3>Newsletter</h3>
                        </div>
                        <p>Must explain to you how all this mistaken idea pleasure born and give you a complete
                            account.</p>
                        <form>
                            <div class="input-1">
                                <input type="email" class="form-control" placeholder="Email Address *" required>
                            </div>
                            <div class="submit clearfix">
                                <button type="submit"><i class="ti-email"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div> <!-- end container -->
        <div class="shadow-shape">
            <svg width="1319" height="1567" viewBox="0 0 1319 1567" fill="none">
                <g filter="url(#filter0_f_39_3832)">
                    <circle cx="803" cy="803" r="303" fill="#59C378" fill-opacity="0.5" />
                </g>
                <defs>
                    <filter id="filter0_f_39_3832" x="0" y="0" width="1606" height="1606"
                        filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                        <feFlood flood-opacity="0" result="BackgroundImageFix" />
                        <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
                        <feGaussianBlur stdDeviation="250" result="effect1_foregroundBlur_39_3832" />
                    </filter>
                </defs>
            </svg>
        </div>
    </div>
    <div class="lower-footer">
        <div class="container">
            <div class="row">
                <div class="separator"></div>
                <p class="copyright">Copyright &copy; 2025 Elito. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>