<div class="wpo-blog-item">
    <div class="wpo-blog-img">
        <img src="assets/images/blog/img-1.jpg" alt="">
    </div>
    <div class="wpo-blog-text">
        <ul>
            <li>January 02, 2025</li>
        </ul>
        <h2><a href="blog-single.php">Have evolved over the years sometimes accident.</a></h2>
        <a class="details" href="blog-single.php">Post Details</a>
    </div>
</div>
<div class="wpo-blog-item">
    <div class="wpo-blog-img">
        <img src="assets/images/blog/img-2.jpg" alt="">
    </div>
    <div class="wpo-blog-text">
        <ul>
            <li>January 03, 2025</li>
        </ul>
        <h2><a href="blog-single.php"> The Internet tend to repeat predefined chunks.</a></h2>
        <a class="details" href="blog-single.php">Post Details</a>
    </div>
</div>
<div class="wpo-blog-item">
    <div class="wpo-blog-img">
        <img src="assets/images/blog/img-3.jpg" alt="">
    </div>
    <div class="wpo-blog-text">
        <ul>
            <li>January 05, 2025</li>
        </ul>
        <h2><a href="blog-single.php">The standard chunk of used since the interested.</a></h2>
        <a class="details" href="blog-single.php">Post Details</a>
    </div>
</div>